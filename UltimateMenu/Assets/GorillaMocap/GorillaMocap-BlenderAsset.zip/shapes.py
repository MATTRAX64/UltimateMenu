"""Recorded Unity blend shapes, evaluated before the imported armature."""
import json
from mathutils import Vector
from .models import AXES,unity_matrix


def build_shapes(obj,item,data):
    shapes=data.get('shapes',[])
    if not shapes:return
    obj.shape_key_add(name='Basis',from_mix=False)
    transform=unity_matrix(item['matrix']).to_3x3()@AXES.to_3x3()
    for index,shape in enumerate(shapes):
        for frame_index,frame in enumerate(shape.get('frames',[])):
            if len(frame['delta'])!=len(obj.data.vertices):raise ValueError('Deformation incompatible avec le mesh')
            key=obj.shape_key_add(name='GMI_Shape_%d_%d'%(index,frame_index),from_mix=False)
            key.slider_min=-10;key.slider_max=10
            for vertex,delta in zip(key.data,frame['delta']):
                vertex.co+=transform@Vector((delta['x'],delta['y'],delta['z']))
    obj['GMI_shapes']=json.dumps([s['name'] for s in shapes],ensure_ascii=False)


def coefficients(frames,weight):
    # Unity interpolates frames piecewise, including extrapolation beyond the last frame.
    points={float(frame['weight']):i for i,frame in enumerate(frames)}
    points.setdefault(0,None)
    points=sorted(points.items())
    result=[0.0]*len(frames)
    if len(points)<2:return result
    segment=next((i for i in range(len(points)-1) if weight<=points[i+1][0]),len(points)-2)
    (a,ia),(b,ib)=points[segment:segment+2]
    t=(weight-a)/(b-a)
    if ia is not None:result[ia]+=1-t
    if ib is not None:result[ib]+=t
    return result


def animate_shapes(obj,data,times,samples):
    if not obj.data.shape_keys:return
    from . import get_fcurve,setdatasToCurves
    keys=obj.data.shape_keys;keys.animation_data_create()
    import bpy
    action=bpy.data.actions.new(obj.name+' - Expressions');keys.animation_data.action=action
    for index,shape in enumerate(data.get('shapes',[])):
        frames=shape.get('frames',[])
        rows=[coefficients(frames,weights[index] if index<len(weights) else 0) for weights in samples]
        for frame_index,frame in enumerate(frames):
            key=keys.key_blocks['GMI_Shape_%d_%d'%(index,frame_index)]
            path='key_blocks['+json.dumps(key.name)+'].value'
            setdatasToCurves(times,[row[frame_index] for row in rows],get_fcurve(action,keys,path,0))

