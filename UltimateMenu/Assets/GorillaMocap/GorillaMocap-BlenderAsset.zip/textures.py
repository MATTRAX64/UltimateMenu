"""Keep every source texture channel, and bind common surface channels in Blender."""
import bpy,json
from .models import local_file

def add_channels(material,folder,surface):
    material['GMI_source_material']=json.dumps(surface,ensure_ascii=False)
    tree=material.node_tree;nodes=tree.nodes;shader=nodes.get('Principled BSDF')
    parameters={entry['name']:entry['values'] for entry in surface.get('parameters',[])}
    def scalar(*names,default=0):
        return next((parameters[name][0] for name in names if name in parameters and parameters[name]),default)
    shader.inputs['Metallic'].default_value=max(0,min(1,scalar('_Metallic')))
    shader.inputs['Roughness'].default_value=max(0,min(1,1-scalar('_Smoothness','_Glossiness')))
    if '_Cull' in parameters:material.use_backface_culling=scalar('_Cull')==2
    channels={};warnings=[]
    for channel in surface.get('channels',[]):
        property=channel['property'];images=channel.get('images',[])
        for image in images:
            path=local_file(folder,image['texture'])
            if not path.is_file():warnings.append(str(path));continue
            texture=nodes.new('ShaderNodeTexImage');texture.name='Game '+property+' '+str(image['index']);texture.label=property+' ['+str(image['index'])+']'
            texture.image=bpy.data.images.load(str(path),check_existing=True);texture.interpolation='Closest'
            texture.location=(-1000,-180*len(channels))
            data_map=any(word in property.lower() for word in ('normal','bump','mask','metallic','occlusion','roughness','deform','depth'))
            if data_map:
                texture.image=texture.image.copy();texture.image.colorspace_settings.name='Non-Color'
            uv=nodes.new('ShaderNodeUVMap');uv.uv_map='UVMap1' if 'Lightmap' in property else surface.get('uvMap','UVMap')
            mapping=nodes.new('ShaderNodeMapping');mapping.vector_type='POINT'
            scale=channel.get('scale',{});offset=channel.get('offset',{})
            mapping.inputs['Scale'].default_value=(scale.get('x',1),scale.get('y',1),1)
            mapping.inputs['Location'].default_value=(offset.get('x',0),offset.get('y',0),0)
            tree.links.new(uv.outputs['UV'],mapping.inputs['Vector']);tree.links.new(mapping.outputs['Vector'],texture.inputs['Vector'])
            selected=surface.get('_slice',channel.get('slice',0)) if channel.get('sliceFromUv1') else channel.get('slice',0)
            if property not in channels or image['index']==selected:channels[property]=(texture,channel)
    if warnings:material['GMI_missing_textures']=json.dumps(warnings)
    def channel(*names):return next((channels[name] for name in names if name in channels),None)
    def multiply_color(socket,image):
        previous=socket.links[0].from_socket if socket.links else None
        blend=nodes.new('ShaderNodeMixRGB');blend.blend_type='MULTIPLY';blend.inputs[0].default_value=1
        if previous:tree.links.new(previous,blend.inputs[1])
        else:blend.inputs[1].default_value=socket.default_value
        tree.links.new(image,blend.inputs[2]);tree.links.new(blend.outputs[0],socket)
    if surface.get('hasVertexColor') and (scalar('_UseVertexColor')>.5 or '_USE_VERTEX_COLOR' in surface.get('keywords',[])):
        color=nodes.new('ShaderNodeVertexColor');color.layer_name='GameColor';multiply_color(shader.inputs['Base Color'],color.outputs['Color'])
    normal=channel('_BumpMap','_NormalMap')
    if normal:
        texture,description=normal
        node=nodes.new('ShaderNodeNormalMap');node.uv_map='UVMap';node.inputs['Strength'].default_value=scalar('_BumpScale','_NormalMapStrength',default=1)
        color=texture.outputs['Color']
        if description.get('format','').upper() in ('BC5','DXT5','BC3'):color=unpack_normal(tree,texture,description['format'].upper())
        tree.links.new(color,node.inputs['Color']);tree.links.new(node.outputs['Normal'],shader.inputs['Normal'])
    emission=channel('_EmissionMap_Atlas','_EmissionMap','_EmissiveTex')
    emission_color=next((parameters[name] for name in ('_EmissionColor','_EmissiveColor') if name in parameters),None)
    enabled=any('EMISSION' in keyword for keyword in surface.get('keywords',[])) or emission_color and any(v>0 for v in emission_color[:3])
    if emission and enabled:
        texture,description=emission
        tint=nodes.new('ShaderNodeMixRGB');tint.blend_type='MULTIPLY';tint.inputs[0].default_value=1
        tint.inputs[2].default_value=tuple(emission_color[:3])+(1,) if emission_color else (1,1,1,1)
        tree.links.new(texture.outputs['Color'],tint.inputs[1]);tree.links.new(tint.outputs[0],shader.inputs['Emission Color']);shader.inputs['Emission Strength'].default_value=scalar('_EmissionStrength',default=1)
    metallic=channel('_MetallicGlossMap')
    if metallic:
        texture,description=metallic;separate=nodes.new('ShaderNodeSeparateColor');tree.links.new(texture.outputs['Color'],separate.inputs[0])
        tree.links.new(separate.outputs['Red'],shader.inputs['Metallic'])
        invert=nodes.new('ShaderNodeMath');invert.operation='SUBTRACT';invert.inputs[0].default_value=1
        tree.links.new(texture.outputs['Alpha'],invert.inputs[1]);tree.links.new(invert.outputs[0],shader.inputs['Roughness'])
    ao=channel('_OcclusionMap')
    if ao:multiply_color(shader.inputs['Base Color'],ao[0].outputs['Color'])
    detail=channel('_DetailAlbedoMap','_DetailTex')
    if detail and any('DETAIL' in keyword for keyword in surface.get('keywords',[])):multiply_color(shader.inputs['Base Color'],detail[0].outputs['Color'])
    # Unity atlas alpha often stores surface data, not transparency.
    keywords=surface.get('keywords',[])
    cutout=any('ALPHATEST' in k or 'ALPHA_CLIP' in k for k in keywords) or scalar('_AlphaClip')>0 or scalar('_Mode')==1
    transparent=any('ALPHABLEND' in k or 'ALPHAPREMULTIPLY' in k or k=='_SURFACE_TYPE_TRANSPARENT' for k in keywords) or scalar('_Surface')==1 or scalar('_Mode') in (2,3)
    if material.get('GMI_body') or surface.get('isFace') or surface.get('uvMap')=='GMI_FaceUV':cutout=transparent=False
    socket=shader.inputs['Alpha']
    if not (cutout or transparent):
        for link in list(socket.links):tree.links.remove(link)
        socket.default_value=1
    if cutout:
        if socket.links:
            previous=socket.links[0].from_socket;threshold=nodes.new('ShaderNodeMath');threshold.operation='GREATER_THAN';threshold.inputs[1].default_value=scalar('_Cutoff','_AlphaCutoff',default=.5)
            tree.links.new(previous,threshold.inputs[0]);tree.links.new(threshold.outputs[0],socket)
    material['GMI_alpha_mode']='CUTOUT' if cutout else 'TRANSPARENT' if transparent else 'OPAQUE'
    # Approximate the game's texture-led character lighting without changing the scene.
    if surface.get('shader')=='GorillaTag/UberShader' and not (cutout or transparent):
        output=next(n for n in nodes if n.type=='OUTPUT_MATERIAL')
        emission=nodes.new('ShaderNodeEmission');emission.name='GMI_GameAmbient';emission.label='Couleur du jeu'
        base=shader.inputs['Base Color']
        if base.links:tree.links.new(base.links[0].from_socket,emission.inputs['Color'])
        else:emission.inputs['Color'].default_value=base.default_value
        emission.inputs['Strength'].default_value=1
        mix=nodes.new('ShaderNodeMixShader');mix.name='GMI_GameLighting';mix.label='Eclairage du jeu / ombres Blender'
        mix.inputs[0].default_value=.65
        tree.links.new(shader.outputs['BSDF'],mix.inputs[1]);tree.links.new(emission.outputs[0],mix.inputs[2])
        tree.links.new(mix.outputs[0],output.inputs['Surface'])


def unpack_normal(tree,texture,format):
    name='Game normal '+('RG' if format=='BC5' else 'AG')
    group=bpy.data.node_groups.get(name)
    if group is None:
        group=bpy.data.node_groups.new(name,'ShaderNodeTree')
        group.interface.new_socket(name='Color',in_out='INPUT',socket_type='NodeSocketColor')
        group.interface.new_socket(name='Alpha',in_out='INPUT',socket_type='NodeSocketFloat')
        group.interface.new_socket(name='Color',in_out='OUTPUT',socket_type='NodeSocketColor')
        inp=group.nodes.new('NodeGroupInput');out=group.nodes.new('NodeGroupOutput');separate=group.nodes.new('ShaderNodeSeparateColor');group.links.new(inp.outputs['Color'],separate.inputs[0])
        r=separate.outputs['Red'] if format=='BC5' else inp.outputs['Alpha'];g=separate.outputs['Green']
        def operation(op,a,b=None,default=0):
            node=group.nodes.new('ShaderNodeMath');node.operation=op;group.links.new(a,node.inputs[0])
            if b is not None:group.links.new(b,node.inputs[1])
            else:node.inputs[1].default_value=default
            return node.outputs[0]
        x=operation('SUBTRACT',operation('MULTIPLY',r,default=2),default=1);y=operation('SUBTRACT',operation('MULTIPLY',g,default=2),default=1)
        squared=operation('ADD',operation('MULTIPLY',x,x),operation('MULTIPLY',y,y))
        negative=operation('MULTIPLY',squared,default=-1);z=operation('SQRT',operation('MAXIMUM',operation('ADD',negative,default=1),default=0))
        blue=operation('MULTIPLY',operation('ADD',z,default=1),default=.5)
        combine=group.nodes.new('ShaderNodeCombineColor');group.links.new(r,combine.inputs['Red']);group.links.new(g,combine.inputs['Green']);group.links.new(blue,combine.inputs['Blue']);group.links.new(combine.outputs[0],out.inputs['Color'])
    node=tree.nodes.new('ShaderNodeGroup');node.node_tree=group
    tree.links.new(texture.outputs['Color'],node.inputs['Color']);tree.links.new(texture.outputs['Alpha'],node.inputs['Alpha'])
    return node.outputs[0]
