"""Actual in-game accessory poses and wardrobe visibility, baked without extra controllers."""
import bpy,gzip,json,struct,math,re
from types import SimpleNamespace
from pathlib import Path
from mathutils import Matrix,Vector
from .models import local_file,unity_matrix,rigid,equipment_rig,driver_for,material_for

def read_motion(path,states):
    frames=[]
    with gzip.open(path,'rb') as stream:
        def integer():
            value=stream.read(4)
            if len(value)!=4:raise ValueError('Capture cosmétique tronquée')
            return struct.unpack('<i',value)[0]
        magic=stream.read(4)
        if magic not in (b'UMC1',b'UMC2'):raise ValueError('Format de mouvement cosmétique inconnu')
        while True:
            value=stream.read(4)
            if not value:break
            if len(value)!=4:raise ValueError('Capture tronquée')
            sample=struct.unpack('<i',value)[0];state=integer();count=integer()
            if state<0 or state>=len(states) or count!=len(states[state]['nodes']):raise ValueError('Squelette incohérent')
            poses={}
            for name in states[state]['nodes']:
                raw=stream.read(48)
                if len(raw)!=48:raise ValueError('Pose tronquée')
                values=struct.unpack('<12f',raw)+(0,0,0,1)
                poses[name]=unity_matrix(values)
            count=integer()
            if count!=states[state]['itemCount']:raise ValueError('Visibilité incohérente')
            visible=[];materials=[];shapes=[]
            for item in range(count):
                flag=stream.read(1)
                if len(flag)!=1:raise ValueError('Visibilité tronquée')
                visible.append(flag!=b'\x00');slots=integer()
                if slots<0 or slots>256:raise ValueError('Nombre de matériaux invalide')
                values=[]
                for slot in range(slots):
                    raw=stream.read(32)
                    if len(raw)!=32:raise ValueError('Matériau tronqué')
                    values.append(struct.unpack('<8f',raw))
                materials.append(values)
                weights=[]
                if magic==b'UMC2':
                    size=integer()
                    if size<0 or size>4096:raise ValueError('Nombre de deformations invalide')
                    raw=stream.read(size*4)
                    if len(raw)!=size*4:raise ValueError('Deformations tronquees')
                    weights=list(struct.unpack('<'+str(size)+'f',raw))
                    if not all(math.isfinite(v) for v in weights):raise ValueError('Deformation non finie')
                shapes.append(weights)
            frames.append({'sample':sample,'state':state,'poses':poses,'visible':visible,'materials':materials,'shapes':shapes})
    return frames

def key_visibility(obj,frames,values):
    previous=None
    for frame,show in zip(frames,values):
        hidden=not show
        if hidden==previous:continue
        obj.hide_viewport=hidden;obj.keyframe_insert('hide_viewport',frame=frame)
        obj.hide_render=hidden;obj.keyframe_insert('hide_render',frame=frame);previous=hidden
    if obj.animation_data:
        from . import list_existing_fcurves
        for curve in list_existing_fcurves(obj.animation_data.action,obj):
            for key in curve.keyframe_points:key.interpolation='CONSTANT'

def uv_animation(material,frames,values):
    if not material or not material.use_nodes:return
    previous=None
    for frame,value in zip(frames,values):
        if not value or value==previous:continue
        previous=value
        for name,start in [('GMI_BaseUV',0),('GMI_MouthUV',4)]:
            node=material.node_tree.nodes.get(name)
            if not node:continue
            node.inputs['Scale'].default_value=(*value[start:start+2],1)
            node.inputs['Location'].default_value=(*value[start+2:start+4],0)
            node.inputs['Scale'].keyframe_insert('default_value',frame=frame)
            node.inputs['Location'].keyframe_insert('default_value',frame=frame)
    tree=material.node_tree
    if tree.animation_data:
        from . import list_existing_fcurves
        for curve in list_existing_fcurves(tree.animation_data.action,tree):
            for key in curve.keyframe_points:key.interpolation='CONSTANT'

def face_polygons(obj):
    # The supplied rig marks face polygons in red in its tiny RGB mask atlas.
    mask=obj.data.uv_layers.get('mask')
    if not mask:return []
    image=next((image for image in bpy.data.images if image.name.startswith('gorillatag_mask') and tuple(image.size)==(4,4)),None)
    if not image:return []
    width,height=image.size;pixels=list(image.pixels);result=[]
    for polygon in obj.data.polygons:
        uv=sum((mask.data[i].uv for i in polygon.loop_indices),Vector((0,0)))/len(polygon.loop_indices)
        x=int(uv.x*width)%width;y=int(uv.y*height)%height;at=(y*width+x)*4
        if pixels[at]>.8 and pixels[at+1]<.2 and pixels[at+2]<.2:result.append(polygon)
    return result

def apply_face(rig,folder,item,frames,shown,material_values):
    surface=dict(item['materials'][0]);surface['uvMap']='GMI_FaceUV'
    # Keep the real blank base and mouth as distinct images; never synthesize a face.
    if surface.get('directTexture'):surface['texture']=surface['directTexture']
    material=material_for(folder,surface);material.name='Visage du jeu'
    for obj in rig.children_recursive:
        if obj.type!='MESH' or 'GorillaTag_Model' not in obj.name:continue
        polygons=face_polygons(obj)
        if not polygons:continue
        uv=obj.data.uv_layers.get('GMI_FaceUV') or obj.data.uv_layers.new(name='GMI_FaceUV')
        base=obj.data.uv_layers.get('UVMap')
        for polygon in polygons:
            for index in polygon.loop_indices:uv.data[index].uv=base.data[index].uv*.5+Vector((0,.5))
        common=bpy.data.materials.get(obj.get('GMI_face_material',''))
        if common is None:
            common=bpy.data.materials.new('Visage anime du jeu');common.use_nodes=True
            common.node_tree.nodes.clear();output=common.node_tree.nodes.new('ShaderNodeOutputMaterial')
            base_group=shader_group(obj.data.materials[polygons[0].material_index])
            node=common.node_tree.nodes.new('ShaderNodeGroup');node.node_tree=base_group
            common.node_tree.links.new(node.outputs[0],output.inputs['Surface'])
            slot=len(obj.data.materials);obj.data.materials.append(common);obj['GMI_face_material']=common.name
            for polygon in polygons:polygon.material_index=slot
        tree=common.node_tree;output=tree.nodes.get('Material Output');previous_shader=output.inputs['Surface'].links[0].from_socket
        group=shader_group(material)
        node=tree.nodes.new('ShaderNodeGroup');node.node_tree=group
        mix=tree.nodes.new('ShaderNodeMixShader')
        tree.links.new(previous_shader,mix.inputs[1]);tree.links.new(node.outputs[0],mix.inputs[2]);tree.links.new(mix.outputs[0],output.inputs['Surface'])
        previous=None
        for frame,visible in zip(frames,shown):
            if visible==previous:continue
            mix.inputs[0].default_value=1 if visible else 0;mix.inputs[0].keyframe_insert('default_value',frame=frame);previous=visible
        from . import list_existing_fcurves
        if tree.animation_data:
            for curve in list_existing_fcurves(tree.animation_data.action,tree):
                for key in curve.keyframe_points:key.interpolation='CONSTANT'
        # The source geometry uses half-size face UVs in the upper half of the atlas.
        uv_animation(SimpleNamespace(use_nodes=True,node_tree=group),frames,[values[0] if values else None for values in material_values])
    return material

def shader_group(material):
    group=bpy.data.node_groups.new(material.name+' - Shader','ShaderNodeTree')
    group.interface.new_socket(name='Shader',in_out='OUTPUT',socket_type='NodeSocketShader')
    copies={}
    for source in material.node_tree.nodes:
        if source.type=='OUTPUT_MATERIAL':continue
        node=group.nodes.new(source.bl_idname);node.name=source.name;copies[source.name]=node
        for property in ('node_tree','image','uv_map','vector_type','blend_type','operation','interpolation','extension'):
            if hasattr(source,property):
                try:setattr(node,property,getattr(source,property))
                except (TypeError,AttributeError):pass
        for index,socket in enumerate(source.inputs):
            if hasattr(socket,'default_value') and index<len(node.inputs):
                try:node.inputs[index].default_value=socket.default_value
                except (TypeError,ValueError):pass
    for link in material.node_tree.links:
        if link.to_node.type=='OUTPUT_MATERIAL':continue
        source=copies[link.from_node.name];target=copies[link.to_node.name]
        source_index=list(link.from_node.outputs).index(link.from_socket);target_index=list(link.to_node.inputs).index(link.to_socket)
        group.links.new(source.outputs[source_index],target.inputs[target_index])
    output=group.nodes.new('NodeGroupOutput')
    original=next(n for n in material.node_tree.nodes if n.type=='OUTPUT_MATERIAL')
    if original.inputs['Surface'].links:
        link=original.inputs['Surface'].links[0];index=list(link.from_node.outputs).index(link.from_socket)
        group.links.new(copies[link.from_node.name].outputs[index],output.inputs[0])
    return group

def anchor_for(item,nodes):
    lower=item['path'].lower()
    target='head' if '/head[' in lower else 'hand.L' if '/hand.l[' in lower else 'hand.R' if '/hand.r[' in lower else 'forearm.L' if '/forearm.l[' in lower else 'forearm.R' if '/forearm.r[' in lower else 'torso'
    candidates=[path for path in nodes if driver_for(path)==target]
    candidates.sort(key=lambda path:(not re.sub(r'\[\d+\]$','',path.rsplit('/',1)[-1]).endswith('new'),len(path)))
    return target,candidates[0] if candidates else None

def import_timeline(context,movement,rig):
    from . import scale_frame_range
    from .models import body_appearance
    folder=Path(movement).resolve().parent
    info=json.loads((folder/'CosmeticTimeline.json').read_text(encoding='utf-8'))
    if info.get('schema')!=1:raise ValueError('Version de tenue inconnue')
    records=read_motion(local_file(folder,info['motion']),info['states'])
    raw=Path(movement).read_text(encoding='utf-8-sig').splitlines();header=raw[0].lstrip('#').split('$');rate=float(header[1])
    count=sum(bool(line.strip()) and not line.startswith('#') for line in raw)
    frames=scale_frame_range(count,float(header[4].replace(',','.'))*rate,float(header[5].replace(',','.'))*rate)
    records=[record for record in records if 0<=record['sample']<len(frames)]
    times=[frames[record['sample']] for record in records]
    if not records:return [],[]
    real_model=any(any(item.get('kind')=='body' for item in json.loads(local_file(folder,state['manifest']).read_text(encoding='utf-8'))['items']) for state in info['states'])
    parent=rig.parent;collection=bpy.data.collections.new('Cosmetiques - '+rig.name);collection['GMI_owned']=True;rig.users_collection[0].children.link(collection)
    old_frame=context.scene.frame_current;old_subframe=context.scene.frame_subframe
    target_samples=[]
    try:
        for frame in ([] if real_model else times):
            integer=math.floor(frame);context.scene.frame_set(integer,subframe=frame-integer)
            evaluated=rig.evaluated_get(context.evaluated_depsgraph_get());space=parent.matrix_world.inverted_safe()@evaluated.matrix_world
            target_samples.append({bone:space@evaluated.pose.bones[bone].matrix for bone in ['torso','head','hand.L','hand.R','forearm.L','forearm.R'] if bone in evaluated.pose.bones})
        imported=[];warnings=[]
        for state_index,state in enumerate(info['states']):
            manifest_path=local_file(folder,state['manifest']);assets=manifest_path.parent
            manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
            nodes={node['path']:node for node in manifest['skeleton']}
            source={path:unity_matrix(node['matrix']) for path,node in nodes.items()}
            rest={path:rigid(matrix) for path,matrix in source.items()}
            matching=[i for i,record in enumerate(records) if record['state']==state_index]
            if not matching:continue
            for index,item in enumerate(manifest['items']):
                existing=set(collection.objects)
                try:
                    shown=[record['state']==state_index and record['visible'][index] for record in records]
                    values=[record['materials'][index] if record['state']==state_index else [] for record in records]
                    if 'gorillaface' in item['name'].lower() and not real_model:
                        apply_face(rig,assets,item,times,shown,values);continue
                    geometry=json.loads(local_file(assets,item['geometry']).read_text(encoding='utf-8'))
                    item_source=dict(source);item_rest=dict(rest)
                    bones=geometry.get('bones',[]);bindposes=geometry.get('bindposes',[])
                    if len(geometry.get('restVertices',[]))==len(geometry['vertices']) and len(bindposes)==len(bones)*16 and bones and geometry.get('weights'):
                        geometry=dict(geometry);geometry['vertices']=geometry['restVertices']
                        if len(geometry.get('restNormals',[]))==len(geometry['vertices']):geometry['normals']=geometry['restNormals']
                        renderer_matrix=unity_matrix(item['matrix'])
                        for bone_index,path in enumerate(bones):
                            if path not in item_source:continue
                            bind=unity_matrix(bindposes[bone_index*16:(bone_index+1)*16])
                            item_source[path]=renderer_matrix@bind.inverted_safe()
                            item_rest[path]=rigid(item_source[path])
                    if 'gorillaface' in item['name'].lower():
                        item=dict(item);item['materials']=[dict(surface,isFace=True) for surface in item['materials']]
                        for surface in item['materials']:
                            if surface.get('directTexture'):surface['texture']=surface['directTexture']
                    target,anchor=anchor_for(item,nodes)
                    poses=[];last=None
                    for position,record in enumerate(records):
                        if record['state']==state_index:
                            actual=record['poses']
                            shift=target_samples[position][target].translation-actual[anchor].translation if not real_model and anchor in actual and target in target_samples[position] else Vector((0,0,0))
                            last={path:Matrix.Translation(shift)@actual[path]@item_source[path].inverted_safe()@item_rest[path] for path in actual if path in item_source}
                        poses.append(last if last is not None else item_rest)
                    item['_folder']=str(assets)
                    arm,obj=equipment_rig(context,item,geometry,nodes,item_rest,parent,collection,times,poses)
                    from .shapes import animate_shapes
                    animate_shapes(obj,geometry,times,[record['shapes'][index] if record['state']==state_index else [] for record in records])
                    imported.append(arm);key_visibility(obj,times,shown);key_visibility(arm,times,shown)
                    if item.get('kind')=='body':
                        body_appearance(raw,obj,frames)
                        for old in rig.children_recursive:
                            if old.type=='MESH' and 'GorillaTag_Model' in old.name:old.hide_render=True;old.hide_set(True)
                        rig.hide_set(True)
                    for slot,material in enumerate(obj.data.materials):uv_animation(material,times,[v[slot] if slot<len(v) else None for v in values])
                except Exception as error:
                    if context.object and context.object.mode!='OBJECT':bpy.ops.object.mode_set(mode='OBJECT')
                    for obj in list(collection.objects):
                        if obj not in existing:bpy.data.objects.remove(obj,do_unlink=True)
                    warnings.append(item['name']+': '+str(error))
        return imported,warnings
    finally:context.scene.frame_set(old_frame,subframe=old_subframe)
