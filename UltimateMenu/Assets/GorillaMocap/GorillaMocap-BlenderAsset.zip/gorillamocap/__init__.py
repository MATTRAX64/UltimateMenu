bl_info = {"name": "GorillaMocap", "author": "UltimateMenu -> GorillaMocap", "version": (6, 2, 0), "blender": (2, 80, 0), "mocapdata": (2, 1, 0), "category": "Animation"}
import bpy, os, math
from mathutils import Euler, Quaternion, Vector
from math import radians
from bpy.props import StringProperty, BoolProperty, CollectionProperty, IntProperty, EnumProperty, FloatProperty
from bpy.types import PropertyGroup, AddonPreferences, Panel, UIList, Operator
MOCAP_TAG = "GMI"

TRANSLATIONS = {
    "fr": {
        "no_folder": "Aucun dossier selectionne",
        "choose_folder": "Selectionner le dossier",
        "update": "Update",
        "no_tracker": "Aucun mocap charge. Choisis un dossier et fait Update.",
        "trackers_available": "Trackers disponibles :",
        "session": "Session",
        "validate": "Valider",
        "reset": "Reset",
        "pref_folder_label": "Dossier Mocap par defaut",
        "pref_lang_label": "Langue",
        "cam_fix_title": "Fix rotation camera",
        "cam_fix_global": "Global (autour de l'origine monde) :",
        "cam_fix_local": "Local (repere de la camera) :",
        "cam_fix_apply": "Appliquer sur la camera selectionnee",
    },
    "en": {
        "no_folder": "No folder selected",
        "choose_folder": "Select folder",
        "update": "Update",
        "no_tracker": "No mocap loaded. Choose a folder and hit Update.",
        "trackers_available": "Available trackers:",
        "session": "Session",
        "validate": "Validate",
        "reset": "Reset",
        "pref_folder_label": "Default Mocap Folder",
        "pref_lang_label": "Language",
        "cam_fix_title": "Camera rotation fix",
        "cam_fix_global": "Global (around world origin):",
        "cam_fix_local": "Local (camera's own frame):",
        "cam_fix_apply": "Apply to selected camera",
    },
    "de": {
        "no_folder": "Kein Ordner ausgewahlt",
        "choose_folder": "Ordner auswahlen",
        "update": "Aktualisieren",
        "no_tracker": "Kein Mocap geladen. Wahle einen Ordner und klicke auf Aktualisieren.",
        "trackers_available": "Verfugbare Tracker:",
        "session": "Sitzung",
        "validate": "Bestatigen",
        "reset": "Zurucksetzen",
        "pref_folder_label": "Standard-Mocap-Ordner",
        "pref_lang_label": "Sprache",
        "cam_fix_title": "Kamera-Rotationsfix",
        "cam_fix_global": "Global (um den Weltursprung):",
        "cam_fix_local": "Lokal (Kamera-eigenes Koordinatensystem):",
        "cam_fix_apply": "Auf ausgewahlte Kamera anwenden",
    },
    "es": {
        "no_folder": "Ninguna carpeta seleccionada",
        "choose_folder": "Seleccionar carpeta",
        "update": "Actualizar",
        "no_tracker": "No hay mocap cargado. Elige una carpeta y pulsa Actualizar.",
        "trackers_available": "Trackers disponibles:",
        "session": "Sesion",
        "validate": "Validar",
        "reset": "Restablecer",
        "pref_folder_label": "Carpeta Mocap por defecto",
        "pref_lang_label": "Idioma",
        "cam_fix_title": "Fix de rotacion de camara",
        "cam_fix_global": "Global (alrededor del origen del mundo):",
        "cam_fix_local": "Local (marco propio de la camara):",
        "cam_fix_apply": "Aplicar a la camara seleccionada",
    },
    "it": {
        "no_folder": "Nessuna cartella selezionata",
        "choose_folder": "Seleziona cartella",
        "update": "Aggiorna",
        "no_tracker": "Nessun mocap caricato. Scegli una cartella e premi Aggiorna.",
        "trackers_available": "Tracker disponibili:",
        "session": "Sessione",
        "validate": "Conferma",
        "reset": "Reimposta",
        "pref_folder_label": "Cartella Mocap predefinita",
        "pref_lang_label": "Lingua",
        "cam_fix_title": "Fix rotazione camera",
        "cam_fix_global": "Globale (attorno all'origine del mondo):",
        "cam_fix_local": "Locale (sistema proprio della camera):",
        "cam_fix_apply": "Applica alla camera selezionata",
    },
    "pt": {
        "no_folder": "Nenhuma pasta selecionada",
        "choose_folder": "Selecionar pasta",
        "update": "Atualizar",
        "no_tracker": "Nenhum mocap carregado. Escolha uma pasta e clique em Atualizar.",
        "trackers_available": "Trackers disponiveis:",
        "session": "Sessao",
        "validate": "Confirmar",
        "reset": "Redefinir",
        "pref_folder_label": "Pasta Mocap padrao",
        "pref_lang_label": "Idioma",
        "cam_fix_title": "Fix de rotacao da camera",
        "cam_fix_global": "Global (ao redor da origem do mundo):",
        "cam_fix_local": "Local (referencial proprio da camera):",
        "cam_fix_apply": "Aplicar a camera selecionada",
    },
    "ja": {
        "no_folder": "\u30d5\u30a9\u30eb\u30c0\u304c\u9078\u629e\u3055\u308c\u3066\u3044\u307e\u305b\u3093",
        "choose_folder": "\u30d5\u30a9\u30eb\u30c0\u3092\u9078\u629e",
        "update": "\u66f4\u65b0",
        "no_tracker": "\u30e2\u30fc\u30ad\u30e3\u30c3\u30d7\u672a\u8aad\u8fbc\u3002\u30d5\u30a9\u30eb\u30c0\u3092\u9078\u3093\u3067\u66f4\u65b0\u3092\u62bc\u3057\u3066\u304f\u3060\u3055\u3044\u3002",
        "trackers_available": "\u5229\u7528\u53ef\u80fd\u306a\u30c8\u30e9\u30c3\u30ab\u30fc:",
        "session": "\u30bb\u30c3\u30b7\u30e7\u30f3",
        "validate": "\u78ba\u5b9a",
        "reset": "\u30ea\u30bb\u30c3\u30c8",
        "pref_folder_label": "\u30c7\u30d5\u30a9\u30eb\u30c8\u306e\u30e2\u30fc\u30ad\u30e3\u30c3\u30d7\u30d5\u30a9\u30eb\u30c0",
        "pref_lang_label": "\u8a00\u8a9e",
        "cam_fix_title": "\u30ab\u30e1\u30e9\u56de\u8ee2\u88dc\u6b63",
        "cam_fix_global": "\u30b0\u30ed\u30fc\u30d0\u30eb\uff08\u30ef\u30fc\u30eb\u30c9\u539f\u70b9\u5468\u308a\uff09:",
        "cam_fix_local": "\u30ed\u30fc\u30ab\u30eb\uff08\u30ab\u30e1\u30e9\u81ea\u8eab\u306e\u5ea7\u6a19\u7cfb\uff09:",
        "cam_fix_apply": "\u9078\u629e\u3057\u305f\u30ab\u30e1\u30e9\u306b\u9069\u7528",
    },
    "ru": {
        "no_folder": "\u041f\u0430\u043f\u043a\u0430 \u043d\u0435 \u0432\u044b\u0431\u0440\u0430\u043d\u0430",
        "choose_folder": "\u0412\u044b\u0431\u0440\u0430\u0442\u044c \u043f\u0430\u043f\u043a\u0443",
        "update": "\u041e\u0431\u043d\u043e\u0432\u0438\u0442\u044c",
        "no_tracker": "\u041c\u043e\u043a\u0430\u043f \u043d\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043d. \u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u043f\u0430\u043f\u043a\u0443 \u0438 \u043d\u0430\u0436\u043c\u0438\u0442\u0435 \u041e\u0431\u043d\u043e\u0432\u0438\u0442\u044c.",
        "trackers_available": "\u0414\u043e\u0441\u0442\u0443\u043f\u043d\u044b\u0435 \u0442\u0440\u0435\u043a\u0435\u0440\u044b:",
        "session": "\u0421\u0435\u0441\u0441\u0438\u044f",
        "validate": "\u041f\u043e\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044c",
        "reset": "\u0421\u0431\u0440\u043e\u0441",
        "pref_folder_label": "\u041f\u0430\u043f\u043a\u0430 \u043c\u043e\u043a\u0430\u043f\u0430 \u043f\u043e \u0443\u043c\u043e\u043b\u0447\u0430\u043d\u0438\u044e",
        "pref_lang_label": "\u042f\u0437\u044b\u043a",
        "cam_fix_title": "\u041a\u043e\u0440\u0440\u0435\u043a\u0446\u0438\u044f \u043f\u043e\u0432\u043e\u0440\u043e\u0442\u0430 \u043a\u0430\u043c\u0435\u0440\u044b",
        "cam_fix_global": "\u0413\u043b\u043e\u0431\u0430\u043b\u044c\u043d\u043e (\u0432\u043e\u043a\u0440\u0443\u0433 \u043d\u0430\u0447\u0430\u043b\u0430 \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442 \u043c\u0438\u0440\u0430):",
        "cam_fix_local": "\u041b\u043e\u043a\u0430\u043b\u044c\u043d\u043e (\u0441\u043e\u0431\u0441\u0442\u0432\u0435\u043d\u043d\u0430\u044f \u0441\u0438\u0441\u0442\u0435\u043c\u0430 \u043a\u0430\u043c\u0435\u0440\u044b):",
        "cam_fix_apply": "\u041f\u0440\u0438\u043c\u0435\u043d\u0438\u0442\u044c \u043a \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u043e\u0439 \u043a\u0430\u043c\u0435\u0440\u0435",
    },
}

def tr(context, key):
    try:
        lang = get_prefs(context).language
    except Exception:
        lang = "fr"
    d = TRANSLATIONS.get(lang, TRANSLATIONS["fr"])
    return d.get(key, TRANSLATIONS["fr"].get(key, key))

def append_collection(bn="Gorilla_IK_Rig.blend", cn="Gorilla_IK_Rig"):
    bp = os.path.join(os.path.dirname(__file__), bn)
    with bpy.data.libraries.load(bp, link=False) as (df, dt):
        if cn not in df.collections: return None
        dt.collections = [cn]
    col = dt.collections[0]
    rig = next((o for o in col.objects if o.type == 'ARMATURE'), None)
    bpy.context.scene.collection.children.link(col)
    return rig

def delete_collection_recursive(col):
    if not col: return
    try:
        children = list(col.children)
    except ReferenceError:
        return
    for ch in children:
        try: delete_collection_recursive(ch)
        except ReferenceError: pass
    try:
        objs = list(col.objects)
    except ReferenceError:
        return
    for o in objs:
        try: bpy.data.objects.remove(o, do_unlink=True)
        except ReferenceError: pass
    try:
        for sc in bpy.data.scenes:
            if col.name in sc.collection.children: sc.collection.children.unlink(col)
        bpy.data.collections.remove(col)
    except ReferenceError:
        pass

def add_constraint(rig, bone, tr, loc=True, rot=True):
    if loc:
        c = bone.constraints.new('COPY_LOCATION'); c.target, c.subtarget = rig, tr.name
    if rot:
        c = bone.constraints.new('COPY_ROTATION'); c.target, c.subtarget = rig, tr.name

def finger_track(rig, bone, tr, x, y, z):
    c = bone.constraints.new('TRANSFORM')
    c.target, c.subtarget, c.target_space, c.owner_space = rig, tr.name, "LOCAL", "LOCAL"
    c.from_max_x, c.map_to = 1.0, "ROTATION"
    c.map_to_x_from = c.map_to_y_from = c.map_to_z_from = 'X'
    c.to_max_x_rot, c.to_max_y_rot, c.to_max_z_rot = radians(x), radians(y), radians(z)

def show_trackers(a):
    pb = a.pose.bones
    torso, hL, hR, head = pb.get("torso"), pb.get("hand_controller.L"), pb.get("hand_controller.R"), pb.get("head")
    iR, mR, tR = pb.get("index_control.R"), pb.get("middle_control.R"), pb.get("thumb_control.R")
    iL, mL, tL = pb.get("index_control.L"), pb.get("middle_control.L"), pb.get("thumb_control.L")
    add_constraint(a, torso, pb.get("mm_torso")); add_constraint(a, head, pb.get("mm_head"))
    add_constraint(a, hL, pb.get("mm_hand.L")); add_constraint(a, hR, pb.get("mm_hand.R"))
    iL["mm_z"], mL["mm_z"], tL["mm_x"] = 75.0, 75.0, 65.0
    iR["mm_z"], mR["mm_z"], tR["mm_x"] = -75.0, -75.0, 65.0
    finger_track(a, iL, pb.get("mm_index.L"), 0, 0, 75); finger_track(a, mL, pb.get("mm_middle.L"), 0, 0, 75)
    finger_track(a, tL, pb.get("mm_thumb.L"), 65, 0, 0)
    finger_track(a, iR, pb.get("mm_index.R"), 0, 0, -75); finger_track(a, mR, pb.get("mm_middle.R"), 0, 0, -75)
    finger_track(a, tR, pb.get("mm_thumb.R"), 65, 0, 0)
    bc = getattr(a.data, "collections", None)
    mc = bc.get("mocap") if bc is not None else None
    if mc: mc.is_visible = True

def read_header(fp):
    try:
        with open(fp, 'r') as f: first = f.readline().strip()
    except OSError:
        return None
    if not first: return None
    parts = (first[1:] if first.startswith("#") else first).split("$")
    if len(parts) < 6: return None
    try:
        v = parts[0].split("."); mj, mn = int(float(v[0])), int(float(v[1]))
    except (ValueError, IndexError):
        return None
    if mj != 2 or mn != 1: return None
    return {"framerate": parts[1], "name": parts[2], "start": parts[4], "end": parts[5],
            "type": parts[6] if len(parts) > 6 else ("camera" if "camera" in parts[2].lower() else "player")}

def guess_session(fn, tn):
    base = os.path.splitext(fn)[0]
    if tn and base.endswith(tn):
        s = base[: -len(tn)].rstrip("_")
        return s if s else base
    return base

def scan_mocap_folder(folder):
    res = []
    if not os.path.isdir(folder): return res
    for fn in sorted(os.listdir(folder)):
        if not fn.lower().endswith(".txt"): continue
        fp = os.path.join(folder, fn)
        h = read_header(fp)
        if h is None: continue
        cam = h.get("type") == "camera" or "camera" in fn.lower()
        nm = h.get("name", os.path.splitext(fn)[0])
        res.append({"name": nm, "filepath": fp, "is_camera": cam, "session": guess_session(fn, nm)})
    return res

def commacheck(s): return s.replace(",", ".")

def assignPlayerInfo(name, color, a):
    sn = name.split("_")[1] if "_" in name else name
    a.name = f"Gorilla[{name}]"
    for ch in a.children:
        if "GorillaTag_Name" in ch.name: ch.data.body = sn
        if "GorillaTag_Model" in ch.name:
            for slot in ch.material_slots:
                mat = slot.material
                if mat is None: continue
                nm = mat.copy()
                gs = nm.node_tree.nodes.get('GorillaTagColorShader')
                if gs is None: continue
                gs.inputs['PrimaryColor'].default_value = color
                ch.data.materials.clear(); ch.data.materials.append(nm)

def _strip_header_lines(ls): return [l for l in ls if not l.startswith("#")]

def scale_frame_range(n, s, e):
    if n < 2: return [round(s)]
    step = (e - s) / (n - 1)
    return [round(s + i * step) for i in range(n)]

def get_fcurve(action, target_id, data_path, index):
    # Blender 5.0+ a retire l'ancienne API action.fcurves (systeme de Slots/
    # Layers/Channelbags introduit en 4.4, legacy API supprimee en 5.0).
    # action.fcurve_ensure_for_datablock existe depuis 4.4 et gere ca pour nous.
    # Avant 4.4, on retombe sur l'ancienne API directement sur l'action.
    if hasattr(action, "fcurve_ensure_for_datablock"):
        return action.fcurve_ensure_for_datablock(target_id, data_path, index=index)
    fc = action.fcurves.find(data_path, index=index)
    return fc if fc else action.fcurves.new(data_path, index=index)

def list_existing_fcurves(action, target_id):
    # Idem get_fcurve : action.fcurves n'existe plus en 5.0+, il faut passer
    # par les layers/channelbags lies au slot du datablock cible. On ne cree
    # rien ici, on lit uniquement ce qui existe deja.
    if hasattr(action, "layers"):
        result = []
        slot = None
        for s in action.slots:
            if s.target_id_type == target_id.id_type and s.identifier[2:] == target_id.name:
                slot = s
                break
        if slot is None:
            return []
        for layer in action.layers:
            for strip in layer.strips:
                cb = strip.channelbag(slot, ensure=False)
                if cb is None: continue
                result.extend(cb.fcurves)
        return result
    return list(action.fcurves)

def setdatasToCurves(frames, samples, fc):
    fc.keyframe_points.add(count=len(frames))
    fc.keyframe_points.foreach_set("co", [x for co in zip(frames, samples) for x in co])
    fc.update()

def speed_decodeMocapOptimized(lines, bones, a, sf, ef):
    dd = {}
    prevq = [Quaternion() for _ in bones]
    for li, line in enumerate(lines):
        line = line.replace('(', '').replace(')', '')
        for si, el in enumerate(line.split("$")):
            if "~" in el:
                loc_s, rot_s = el.split('~')
                loc = [float(c) for c in loc_s.split(',')]
                rot = [float(c) for c in rot_s.split(',')]
                nl = [loc[0], loc[1], -loc[2]]
                nr = [rot[3], rot[0], -rot[1], -rot[2]]
                q = Euler((0, radians(180), 0), 'XYZ').to_quaternion() @ Quaternion(nr)
                nr = [q.w, q.x, q.y, q.z]
                if si in (1, 2): q = Quaternion(nr) @ Quaternion((1, 0, 0), radians(90))
                if li > 0 and prevq[si].dot(q) < 0.0: q = -q
                prevq[si] = q
                conv = nl + [q.w, q.x, q.y, q.z]
            else:
                conv = float(el.replace(',', '.') if ',' in el else el)
            dd.setdefault(si, []).append(conv)
    samples_list = list(dd.values())
    if a.animation_data: a.animation_data_clear()
    if len(samples_list) == 5: del bones[4:10]
    a.animation_data_create()
    action = bpy.data.actions.new(name=f"MocapData({a.name})")
    a.animation_data.action = action
    frames = scale_frame_range(len(lines), sf, ef)
    for idx, (bone, od) in enumerate(zip(bones, samples_list)):
        bone.rotation_mode = 'QUATERNION'
        dp = f'pose.bones["{bone.name}"]'
        if idx < 4:
            cols = list(zip(*od))
            for ax in range(3):
                fc = get_fcurve(action, a, dp + ".location", ax)
                setdatasToCurves(frames, cols[ax], fc)
            for ax in range(4):
                fc = get_fcurve(action, a, dp + ".rotation_quaternion", ax)
                setdatasToCurves(frames, cols[3 + ax], fc)
        else:
            fc = get_fcurve(action, a, dp + ".location", 0)
            setdatasToCurves(frames, od, fc)

def open_mocapdata(context, fp, a, actor):
    with open(fp, 'r') as f: raw = f.readlines()
    td = [l.strip() for l in raw]
    if td and td[0].startswith("#"):
        hl = td[0][1:]; td = _strip_header_lines(td)
    else:
        hl = td[0] if td else ""; td = td[1:]
    pi = hl.split('$')
    if len(pi) < 6: return False
    fv = pi[0].split('.')
    if int(float(fv[0])) != 2 or int(float(fv[1])) != 1: return False
    fr = float(pi[1]); name = pi[2]
    sf, ef = float(commacheck(pi[4])) * fr, float(commacheck(pi[5])) * fr
    rgba = tuple(float(v.strip()) for v in pi[3].strip("RGBA()").split(","))[:4]
    assignPlayerInfo(name, rgba, a)
    if actor is not None:
        actor.file_path, actor.framecount, actor.framerate, actor.name = fp, len(td), fr, name
    if a.type == "ARMATURE":
        pb = a.pose.bones
        bones = [pb.get(k) for k in ("mm_head", "mm_hand.L", "mm_hand.R", "mm_torso", "mm_index.L", "mm_middle.L", "mm_thumb.L", "mm_index.R", "mm_middle.R", "mm_thumb.R", "mm_lava")]
        speed_decodeMocapOptimized(td, bones, a, sf, ef)
    return True

def decode_camera_file(fp, cam):
    with open(fp, 'r') as f: lines = [l.strip() for l in f.readlines()]
    if lines and lines[0].startswith("#"):
        hl = lines[0][1:]; lines = _strip_header_lines(lines)
    else:
        hl = lines[0] if lines else ""; lines = lines[1:]
    h = hl.split('$')
    if len(h) < 6: return False
    fr = float(h[1]); sf, ef = float(commacheck(h[4])) * fr, float(commacheck(h[5])) * fr
    if cam.animation_data: cam.animation_data_clear()
    cam.animation_data_create()
    action = bpy.data.actions.new(name=f"MocapData({cam.name})")
    cam.animation_data.action = action
    cam.rotation_mode = 'QUATERNION'
    locs, rots, pq = [], [], Quaternion()
    # Fix valide manuellement dans Blender : Global X 90 (tourne position ET
    # rotation autour de l'origine du monde 0,0,0), puis Local Z 90 (tourne
    # uniquement l'orientation, dans le repere de la camera). Ordre important :
    # global d'abord (multiplication a GAUCHE), local ensuite (a DROITE).
    cam_global_fix = Euler((radians(90), 0, 0), 'XYZ').to_quaternion()
    cam_local_fix = Euler((0, 0, radians(90)), 'XYZ').to_quaternion()
    for li, line in enumerate(lines):
        if not line: continue
        line = line.replace('(', '').replace(')', '')
        ff = line.split("$")[0]
        if "~" not in ff: continue
        loc_s, rot_s = ff.split('~')
        loc = [float(c) for c in loc_s.split(',')]
        rot = [float(c) for c in rot_s.split(',')]
        nl = (loc[0], loc[1], -loc[2])
        nr = [rot[3], rot[0], -rot[1], -rot[2]]
        q = Euler((0, radians(180), 0), 'XYZ').to_quaternion() @ Quaternion(nr)
        nl = cam_global_fix @ Vector(nl)
        q = cam_global_fix @ q @ cam_local_fix
        if li > 0 and pq.dot(q) < 0.0: q = -q
        pq = q
        locs.append(nl); rots.append((q.w, q.x, q.y, q.z))
    if not locs: return False
    frames = scale_frame_range(len(locs), sf, ef)
    for ax in range(3):
        fc = get_fcurve(action, cam, "location", ax)
        setdatasToCurves(frames, [l[ax] for l in locs], fc)
    for ax in range(4):
        fc = get_fcurve(action, cam, "rotation_quaternion", ax)
        setdatasToCurves(frames, [r[ax] for r in rots], fc)
    return True

def import_camera_tracker(context, path, name):
    cd = bpy.data.cameras.new(name=name)
    co = bpy.data.objects.new(name=name, object_data=cd)
    context.scene.collection.objects.link(co)
    co[MOCAP_TAG] = True
    return decode_camera_file(path, co)

def get_prefs(context): return context.preferences.addons[__package__].preferences

class GorillaMocapTrackerEntry(PropertyGroup):
    name: StringProperty(default="")
    filepath: StringProperty(subtype='FILE_PATH', default="")
    is_camera: BoolProperty(default=False)
    session: StringProperty(default="")
    selected: BoolProperty(default=True)

class GorillaMocapSceneProps(PropertyGroup):
    mocap_folder: StringProperty(subtype='DIR_PATH', default="")
    trackers: CollectionProperty(type=GorillaMocapTrackerEntry)
    active_tracker_index: IntProperty(default=0)
    scan_status: StringProperty(default="")
    fix_global_x: FloatProperty(name="Global X", default=0.0, subtype='ANGLE')
    fix_global_y: FloatProperty(name="Global Y", default=0.0, subtype='ANGLE')
    fix_global_z: FloatProperty(name="Global Z", default=0.0, subtype='ANGLE')
    fix_local_x: FloatProperty(name="Local X", default=0.0, subtype='ANGLE')
    fix_local_y: FloatProperty(name="Local Y", default=0.0, subtype='ANGLE')
    fix_local_z: FloatProperty(name="Local Z", default=0.0, subtype='ANGLE')
    fix_panel_expanded: BoolProperty(name="", default=False)

class GorillaMocapPreferences(AddonPreferences):
    bl_idname = __package__
    last_mocap_folder: StringProperty(
        name="", subtype='DIR_PATH', default="",
        description="Dossier ou sont lus/ecrits les fichiers de mocap"
    )
    language: EnumProperty(
        name="", items=[
            ("fr", "Francais", "Interface en francais"),
            ("en", "English", "English interface"),
            ("de", "Deutsch", "Deutsche Oberflache"),
            ("es", "Espanol", "Interfaz en espanol"),
            ("it", "Italiano", "Interfaccia in italiano"),
            ("pt", "Portugues", "Interface em portugues"),
            ("ja", "\u65e5\u672c\u8a9e", "\u65e5\u672c\u8a9e\u30a4\u30f3\u30bf\u30fc\u30d5\u30a7\u30fc\u30b9"),
            ("ru", "\u0420\u0443\u0441\u0441\u043a\u0438\u0439", "\u0418\u043d\u0442\u0435\u0440\u0444\u0435\u0439\u0441 \u043d\u0430 \u0440\u0443\u0441\u0441\u043a\u043e\u043c \u044f\u0437\u044b\u043a\u0435"),
        ], default="fr"
    )
    def draw(self, context):
        layout = self.layout
        box = layout.box()
        col = box.column(align=True)
        col.label(text=tr(context, "pref_folder_label"), icon='FILE_FOLDER')
        col.prop(self, "last_mocap_folder")
        box = layout.box()
        col = box.column(align=True)
        col.label(text=tr(context, "pref_lang_label"), icon='WORLD')
        col.prop(self, "language")

class GORILLAMOCAP_OT_choose_folder(Operator):
    bl_idname = "gorillamocap.choose_folder"
    bl_label = "Choisir le dossier Mocap"
    directory: StringProperty(subtype='DIR_PATH', options={'SKIP_SAVE'})
    def invoke(self, context, event):
        p = get_prefs(context)
        if p.last_mocap_folder: self.directory = p.last_mocap_folder
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
    def execute(self, context):
        props = context.scene.gorillamocap
        props.mocap_folder = self.directory
        get_prefs(context).last_mocap_folder = self.directory
        bpy.ops.gorillamocap.scan_folder()
        return {'FINISHED'}

class GORILLAMOCAP_OT_scan_folder(Operator):
    bl_idname = "gorillamocap.scan_folder"
    bl_label = "Rafraichir"
    def execute(self, context):
        props = context.scene.gorillamocap
        folder = props.mocap_folder
        if not folder or not os.path.isdir(bpy.path.abspath(folder)):
            props.scan_status = "Dossier invalide"
            self.report({'ERROR'}, "Dossier mocap invalide")
            return {'CANCELLED'}
        af = bpy.path.abspath(folder)
        kept = {(t.filepath, t.name): t.selected for t in props.trackers}
        props.trackers.clear()
        found = scan_mocap_folder(af)
        if not found:
            props.scan_status = "Aucun fichier trouve"
            return {'FINISHED'}
        for e in found:
            it = props.trackers.add()
            it.name, it.filepath, it.is_camera, it.session = e["name"], e["filepath"], e["is_camera"], e["session"]
            it.selected = kept.get((it.filepath, it.name), True)
        props.scan_status = f"{len(found)} tracker(s) trouve(s)"
        self.report({'INFO'}, props.scan_status)
        return {'FINISHED'}

class GORILLAMOCAP_OT_toggle_tracker(Operator):
    bl_idname = "gorillamocap.toggle_tracker"
    bl_label = "Toggle Tracker"
    bl_options = {'INTERNAL'}
    index: IntProperty(default=-1)
    def execute(self, context):
        props = context.scene.gorillamocap
        if 0 <= self.index < len(props.trackers): props.trackers[self.index].selected = not props.trackers[self.index].selected
        return {'FINISHED'}

class GORILLAMOCAP_OT_import_selected(Operator):
    bl_idname = "gorillamocap.import_selected"
    bl_label = "Valider"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        props = context.scene.gorillamocap
        sel = [t for t in props.trackers if t.selected]
        if not sel:
            self.report({'WARNING'}, "Aucun tracker selectionne")
            return {'CANCELLED'}
        n = 0
        for t in sel:
            path = bpy.path.abspath(t.filepath)
            if not os.path.isfile(path):
                self.report({'WARNING'}, f"Fichier introuvable : {t.name}")
                continue
            if t.is_camera:
                ok = import_camera_tracker(context, path, t.name)
            else:
                rig = append_collection()
                if rig is None:
                    self.report({'WARNING'}, f"Impossible de creer le rig pour {t.name}")
                    continue
                rig[MOCAP_TAG] = True
                show_trackers(rig)
                ok = open_mocapdata(context, path, rig, None)
            if ok is not False: n += 1
        for w in bpy.context.window_manager.windows:
            for ar in w.screen.areas: ar.tag_redraw()
        self.report({'INFO'}, f"{n} tracker(s) importe(s)")
        return {'FINISHED'}

class GORILLAMOCAP_OT_apply_camera_fix(Operator):
    bl_idname = "gorillamocap.apply_camera_fix"
    bl_label = "Appliquer le fix camera"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        cam = context.active_object
        if cam is None or cam.type != 'CAMERA':
            self.report({'WARNING'}, "Selectionne une camera")
            return {'CANCELLED'}
        if not cam.animation_data or not cam.animation_data.action:
            self.report({'WARNING'}, "Cette camera n'a pas d'animation")
            return {'CANCELLED'}
        p = context.scene.gorillamocap
        # Ordre : rotations globales d'abord (multiplication a GAUCHE, autour de
        # l'origine du monde), puis rotations locales (multiplication a DROITE,
        # dans le repere de la camera), chacune X puis Y puis Z.
        gq = (Euler((p.fix_global_x, 0, 0), 'XYZ').to_quaternion()
              @ Euler((0, p.fix_global_y, 0), 'XYZ').to_quaternion()
              @ Euler((0, 0, p.fix_global_z), 'XYZ').to_quaternion())
        lq = (Euler((p.fix_local_x, 0, 0), 'XYZ').to_quaternion()
              @ Euler((0, p.fix_local_y, 0), 'XYZ').to_quaternion()
              @ Euler((0, 0, p.fix_local_z), 'XYZ').to_quaternion())
        action = cam.animation_data.action
        all_fcs = list_existing_fcurves(action, cam)
        fcs = {fc.array_index: fc for fc in all_fcs if fc.data_path == "rotation_quaternion"}
        loc_fcs = {fc.array_index: fc for fc in all_fcs if fc.data_path == "location"}
        if len(fcs) != 4:
            self.report({'WARNING'}, "F-Curves de rotation introuvables (rotation_quaternion attendu)")
            return {'CANCELLED'}
        if len(loc_fcs) != 3:
            self.report({'WARNING'}, "F-Curves de position introuvables (location attendu)")
            return {'CANCELLED'}
        n = len(fcs[0].keyframe_points)
        pq = Quaternion()
        for i in range(n):
            w = fcs[0].keyframe_points[i].co[1]
            x = fcs[1].keyframe_points[i].co[1]
            y = fcs[2].keyframe_points[i].co[1]
            z = fcs[3].keyframe_points[i].co[1]
            q = Quaternion((w, x, y, z))
            q = gq @ q @ lq
            if i > 0 and pq.dot(q) < 0.0: q = -q
            pq = q
            for ax, val in zip(range(4), (q.w, q.x, q.y, q.z)):
                fcs[ax].keyframe_points[i].co[1] = val
            # La position tourne aussi autour de (0,0,0), mais uniquement avec
            # la rotation globale (le pivot 3D Cursor a l'origine ne fait rien
            # sur la position si la rotation est locale a l'objet).
            lx = loc_fcs[0].keyframe_points[i].co[1]
            ly = loc_fcs[1].keyframe_points[i].co[1]
            lz = loc_fcs[2].keyframe_points[i].co[1]
            new_loc = gq @ Vector((lx, ly, lz))
            for ax, val in zip(range(3), new_loc):
                loc_fcs[ax].keyframe_points[i].co[1] = val
        for fc in fcs.values(): fc.update()
        for fc in loc_fcs.values(): fc.update()
        self.report({'INFO'}, f"Fix applique sur {n} keyframe(s)")
        return {'FINISHED'}

class GORILLAMOCAP_OT_reset_scene(Operator):
    bl_idname = "gorillamocap.reset_scene"
    bl_label = "Reset"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        cols, loose = {}, []
        root_names = {sc.collection.name for sc in bpy.data.scenes}
        for o in bpy.data.objects:
            if not o.get(MOCAP_TAG): continue
            c = o.users_collection[0] if o.users_collection else None
            if c and c.name not in root_names:
                cols[c.name] = c
            else:
                loose.append(o)
        n = len(cols) + len(loose)
        for c in cols.values():
            try: delete_collection_recursive(c)
            except ReferenceError: pass
        for o in loose:
            try: bpy.data.objects.remove(o, do_unlink=True)
            except ReferenceError: pass
        self.report({'INFO'}, f"{n} element(s) mocap supprime(s)")
        return {'FINISHED'}

class GORILLAMOCAP_UL_tracker_list(UIList):
    bl_idname = "GORILLAMOCAP_UL_tracker_list"
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if not item: return
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.prop(item, "selected", text="")
            row.label(text=item.name, icon='CAMERA_DATA' if item.is_camera else 'OUTLINER_OB_ARMATURE')
        elif self.layout_type == 'GRID':
            layout.label(text="", icon='CAMERA_DATA' if item.is_camera else 'OUTLINER_OB_ARMATURE')
    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        return [self.bitflag_filter_item] * len(items), list(range(len(items)))

class GORILLAMOCAP_PT_MainPanel(Panel):
    bl_label = "GorillaMocap"
    bl_idname = "GORILLAMOCAP_PT_MainPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "GorillaMocap"
    def draw(self, context):
        layout = self.layout
        props = context.scene.gorillamocap
        folder = props.mocap_folder
        if not folder:
            ap = context.preferences.addons.get(__package__)
            if ap: folder = ap.preferences.last_mocap_folder
        box = layout.box()
        col = box.column(align=True)
        col.label(text=folder or tr(context, "no_folder"), icon='FILE_FOLDER')
        row = col.row(align=True)
        row.operator("gorillamocap.choose_folder", icon='FILE_FOLDER', text=tr(context, "choose_folder"))
        row.operator("gorillamocap.scan_folder", icon='FILE_REFRESH', text=tr(context, "update"))
        if props.scan_status: box.label(text=props.scan_status, icon='INFO')
        layout.separator()
        if not props.trackers:
            layout.label(text=tr(context, "no_tracker"), icon='INFO')
        else:
            layout.label(text=tr(context, "trackers_available"), icon='ANIM')
            self.draw_grouped_list(layout, props, context)
        layout.separator()
        row = layout.row(align=True)
        row.scale_y = 1.3
        row.operator("gorillamocap.import_selected", icon='CHECKMARK', text=tr(context, "validate"))
        row.operator("gorillamocap.reset_scene", icon='TRASH', text=tr(context, "reset"))
        layout.separator()
        box = layout.box()
        header = box.row(align=True)
        header.prop(props, "fix_panel_expanded",
                    icon='TRIA_DOWN' if props.fix_panel_expanded else 'TRIA_RIGHT',
                    icon_only=True, emboss=False)
        header.label(text=tr(context, "cam_fix_title"), icon='CON_ROTLIKE')
        if props.fix_panel_expanded:
            col = box.column(align=True)
            col.label(text=tr(context, "cam_fix_global"))
            col.prop(props, "fix_global_x")
            col.prop(props, "fix_global_y")
            col.prop(props, "fix_global_z")
            col.separator()
            col.label(text=tr(context, "cam_fix_local"))
            col.prop(props, "fix_local_x")
            col.prop(props, "fix_local_y")
            col.prop(props, "fix_local_z")
            box.operator("gorillamocap.apply_camera_fix", icon='CHECKMARK', text=tr(context, "cam_fix_apply"))
    def draw_grouped_list(self, layout, props, context):
        sessions = {}
        for idx, t in enumerate(props.trackers): sessions.setdefault(t.session, []).append((idx, t))
        for sn, entries in sessions.items():
            box = layout.box()
            box.row().label(text=sn or tr(context, "session"), icon='FILE')
            col = box.column(align=True)
            for idx, t in entries:
                row = col.row(align=True)
                row.prop(t, "selected", text="")
                row.label(text=t.name, icon='CAMERA_DATA' if t.is_camera else 'OUTLINER_OB_ARMATURE')

classes = (GorillaMocapTrackerEntry, GorillaMocapSceneProps, GorillaMocapPreferences, GORILLAMOCAP_OT_choose_folder, GORILLAMOCAP_OT_scan_folder, GORILLAMOCAP_OT_toggle_tracker, GORILLAMOCAP_OT_import_selected, GORILLAMOCAP_OT_apply_camera_fix, GORILLAMOCAP_OT_reset_scene, GORILLAMOCAP_UL_tracker_list, GORILLAMOCAP_PT_MainPanel)

def register():
    for c in classes: bpy.utils.register_class(c)
    bpy.types.Scene.gorillamocap = bpy.props.PointerProperty(type=GorillaMocapSceneProps)

def unregister():
    del bpy.types.Scene.gorillamocap
    for c in reversed(classes): bpy.utils.unregister_class(c)