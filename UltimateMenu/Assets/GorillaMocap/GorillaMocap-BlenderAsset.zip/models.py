"""Import UltimateMenu Models.json snapshots alongside the existing mocap animation."""
import bpy,json,math,re
from pathlib import Path
from mathutils import Matrix,Vector

AXES=Matrix(((1,0,0,0),(0,0,1,0),(0,1,0,0),(0,0,0,1)))

def local_file(folder,name):
    path=(folder/name).resolve()
    if not path.is_relative_to(folder.resolve()): raise ValueError('Chemin hors du dossier de la prise')
    return path

def unity_matrix(values):
    if len(values)!=16 or not all(math.isfinite(v) for v in values):raise ValueError('Matrice invalide')
    matrix=Matrix(tuple(tuple(values[r*4+c] for c in range(4)) for r in range(4)))
    return AXES@matrix@AXES

def rigid(matrix):
    return Matrix.LocRotScale(matrix.translation,matrix.to_quaternion(),Vector((1,1,1)))

def driver_for(path):
    name=re.sub(r'\[\d+\]$','',path.rsplit('/',1)[-1]).lower()
    name=re.sub('[^a-z0-9]','',name).removesuffix('new')
    if name in ('body','bodypivot','torso','chest','spine','hips'):return 'torso'
    if name in ('head','headtarget'):return 'head'
    side='L' if name.endswith('l') or 'left' in name else 'R' if name.endswith('r') or 'right' in name else ''
    if not side:return None
    for prefix,target in [('upperarm','upper_arm'),('forearm','forearm'),('lowerarm','forearm'),('hand','hand'),('wrist','hand')]:
        if name.startswith(prefix):return target+'.'+side
    for prefix,target in [('findex','f_index'),('fmiddle','f_middle'),('thumb','thumb')]:
        match=re.search(prefix+r'(0[123])',name)
        if match:return target+'_'+match[1]+'_'+side
    return None

def material_for(folder,surface,body=False):
    mat=bpy.data.materials.new(surface.get('name') or 'Mocap material')
    mat.use_nodes=True;mat['GMI']=True
    if body:mat['GMI_tintable']=surface.get('_slot',0)==0
    nodes=mat.node_tree.nodes;shader=nodes.get('Principled BSDF')
    shader.inputs['Roughness'].default_value=1;shader.inputs['Metallic'].default_value=0
    rgba=surface.get('color',{})
    color=tuple(rgba.get(axis,1) for axis in ('r','g','b','a'))
    tint=nodes.new('ShaderNodeMixRGB');tint.name='GMI_Tint';tint.blend_type='MULTIPLY'
    tint.inputs[0].default_value=1;tint.inputs[1].default_value=(1,1,1,1);tint.inputs[2].default_value=color
    mat.node_tree.links.new(tint.outputs[0],shader.inputs['Base Color'])
    shader.inputs['Alpha'].default_value=color[3]
    if body:mat['GMI_body']=True
    if surface.get('texture'):
        image_path=local_file(folder,surface['texture'])
        if image_path.is_file():
            texture=nodes.new('ShaderNodeTexImage');texture.image=bpy.data.images.load(str(image_path),check_existing=True)
            texture.interpolation='Closest'
            uv=nodes.new('ShaderNodeUVMap');uv.uv_map=surface.get('uvMap','UVMap');mapping=nodes.new('ShaderNodeMapping');mapping.name='GMI_BaseUV';mapping.vector_type='POINT'
            scale=surface.get('scale',{});offset=surface.get('offset',{})
            mapping.inputs['Scale'].default_value=(scale.get('x',1),scale.get('y',1),1)
            mapping.inputs['Location'].default_value=(offset.get('x',0),offset.get('y',0),0)
            mat.node_tree.links.new(uv.outputs['UV'],mapping.inputs['Vector']);mat.node_tree.links.new(mapping.outputs['Vector'],texture.inputs['Vector'])
            mat.node_tree.links.new(texture.outputs['Color'],tint.inputs[1])
            alpha=nodes.new('ShaderNodeMath');alpha.operation='MULTIPLY';alpha.inputs[1].default_value=color[3]
            mat.node_tree.links.new(texture.outputs['Alpha'],alpha.inputs[0]);mat.node_tree.links.new(alpha.outputs[0],shader.inputs['Alpha'])
    if surface.get('mouthTexture'):
        path=local_file(folder,surface['mouthTexture'])
        if path.is_file():
            mouth=nodes.new('ShaderNodeTexImage');mouth.image=bpy.data.images.load(str(path),check_existing=True);mouth.interpolation='Closest'
            uv=nodes.new('ShaderNodeUVMap');uv.uv_map=surface.get('uvMap','UVMap')
            mapping=nodes.new('ShaderNodeMapping');mapping.name='GMI_MouthUV';mapping.vector_type='POINT'
            scale=surface.get('mouthScale',{});offset=surface.get('mouthOffset',{})
            mapping.inputs['Scale'].default_value=(scale.get('x',1),scale.get('y',1),1)
            mapping.inputs['Location'].default_value=(offset.get('x',0),offset.get('y',0),0)
            mat.node_tree.links.new(uv.outputs['UV'],mapping.inputs['Vector']);mat.node_tree.links.new(mapping.outputs['Vector'],mouth.inputs['Vector'])
            blend=nodes.new('ShaderNodeMixRGB');blend.blend_type='MIX'
            mat.node_tree.links.new(mouth.outputs['Alpha'],blend.inputs[0])
            mat.node_tree.links.new(tint.outputs[0],blend.inputs[1]);mat.node_tree.links.new(mouth.outputs['Color'],blend.inputs[2]);mat.node_tree.links.new(blend.outputs[0],shader.inputs['Base Color'])
    if surface.get('uvMap')=='GMI_FaceUV':
        for link in list(shader.inputs['Alpha'].links):mat.node_tree.links.remove(link)
        shader.inputs['Alpha'].default_value=1
    from .textures import add_channels
    add_channels(mat,folder,surface)
    return mat

def build_mesh(folder,item,data,collection):
    matrix=unity_matrix(item['matrix'])
    vertices=[matrix@(AXES@Vector((v['x'],v['y'],v['z']))) for v in data['vertices']]
    faces=[];slots=[];materials=[];material_indices={}
    reverse=matrix.to_3x3().determinant()>=0
    for slot,submesh in enumerate(data.get('submeshes',[])):
        indices=submesh['indices']
        surfaces=item.get('materials',[])
        # The body has an unassigned face backing submesh which Unity does not draw.
        if item.get('kind')=='body' and slot>=len(surfaces):continue
        surface=surfaces[slot] if slot<len(surfaces) else {}
        images={image['index']:image['texture'] for image in surface.get('slices',[])}
        slices=data.get('atlasSlices',[])
        if len(indices)%3:raise ValueError('Liste de triangles incomplète')
        for i in range(0,len(indices),3):
            a,b,c=indices[i:i+3]
            if min(a,b,c)<0 or max(a,b,c)>=len(vertices):raise ValueError('Indice de sommet invalide')
            slice_index=round(slices[a]) if surface.get('sliceFromUv1') and len(slices)==len(vertices) else surface.get('slice',0)
            key=(slot,slice_index)
            if key not in material_indices:
                material_indices[key]=len(materials)
                resolved=dict(surface)
                resolved['_slot']=slot
                if slice_index in images:resolved['texture']=images[slice_index]
                resolved['_slice']=slice_index
                materials.append(resolved)
            faces.append((a,c,b) if reverse else (a,b,c));slots.append(material_indices[key])
    mesh=bpy.data.meshes.new(item['name']);mesh.from_pydata(vertices,[],faces);mesh.update()
    obj=bpy.data.objects.new(item['name'],mesh);collection.objects.link(obj);obj['GMI']=True
    for surface in materials:mesh.materials.append(material_for(folder,surface,item.get('kind')=='body'))
    for polygon,slot in zip(mesh.polygons,slots):polygon.material_index=min(slot,max(0,len(mesh.materials)-1))
    uv=data.get('uv',[])
    if len(uv)==len(vertices):
        layer=mesh.uv_layers.new(name='UVMap')
        for loop in mesh.loops:
            value=uv[loop.vertex_index];layer.data[loop.index].uv=(value['x'],value['y'])
    for channel in data.get('uvChannels',[]):
        number=channel['channel'];values=channel['values']
        if number==0 or len(values)!=len(vertices):continue
        layer=mesh.uv_layers.new(name='UVMap'+str(number))
        for loop in mesh.loops:value=values[loop.vertex_index];layer.data[loop.index].uv=(value['x'],value['y'])
    colors=data.get('colors',[])
    if len(colors)==len(vertices):
        attribute=mesh.color_attributes.new(name='GameColor',type='FLOAT_COLOR',domain='POINT')
        for target,color in zip(attribute.data,colors):target.color=tuple(color.get(axis,1) for axis in ('r','g','b','a'))
    normals=data.get('normals',[])
    if len(normals)==len(vertices):
        normal_matrix=matrix.inverted_safe().transposed().to_3x3()
        converted=[(normal_matrix@(AXES.to_3x3()@Vector((n['x'],n['y'],n['z'])))).normalized() for n in normals]
        mesh.normals_split_custom_set_from_vertices(converted)
        for polygon in mesh.polygons:polygon.use_smooth=True
    return obj

def sample_motion(context,rig,parent,nodes,rest,frames):
    order=sorted(nodes,key=lambda p:p.count('/'))
    drivers={path:driver_for(path) for path in order}
    for path in order:
        if not nodes[path].get('parent') and not drivers[path]:drivers[path]='torso'
        if not drivers[path] or drivers[path] not in rig.pose.bones:drivers[path]=None
    old_frame=context.scene.frame_current;old_subframe=context.scene.frame_subframe
    base={};samples=[]
    try:
        for frame in frames:
            integer=math.floor(frame);context.scene.frame_set(integer,subframe=frame-integer)
            depsgraph=context.evaluated_depsgraph_get();evaluated=rig.evaluated_get(depsgraph)
            space=parent.matrix_world.inverted_safe()@evaluated.matrix_world
            targets={name:space@evaluated.pose.bones[name].matrix for name in set(drivers.values()) if name}
            if not base:base={name:value.inverted_safe() for name,value in targets.items()}
            pose={}
            for path in order:
                driver=drivers[path];parent_path=nodes[path].get('parent')
                if driver:pose[path]=targets[driver]@base[driver]@rest[path]
                elif parent_path in pose:pose[path]=pose[parent_path]@rest[parent_path].inverted_safe()@rest[path]
                else:pose[path]=rest[path].copy()
            samples.append(pose)
    finally:context.scene.frame_set(old_frame,subframe=old_subframe)
    return samples

def equipment_rig(context,item,data,nodes,rest,parent,collection,frames,samples):
    from . import get_fcurve,setdatasToCurves
    weights=data.get('weights',[]);skin_bones=data.get('bones',[])
    skinned=len(weights)==len(data['vertices']) and bool(weights)
    if item.get('kind')=='body' and not skinned:raise ValueError('Poids du corps indisponibles : rig fourni conservé')
    attach=item.get('attachment')
    if attach not in nodes:attach=item.get('path')
    if attach not in nodes:raise ValueError('Attache absente du squelette')
    used=set()
    if skinned:
        for influence in weights:
            for index,weight in zip(influence['bones'],influence['weights']):
                if weight>0:
                    if index<0 or index>=len(skin_bones) or skin_bones[index] not in nodes:raise ValueError('Poids vers un os inconnu')
                    used.add(skin_bones[index])
    else:used.add(item['path'] if item.get('path') in nodes else attach)
    rigid_item=len(used)==1
    follow_path=next(iter(used)) if rigid_item else item.get('path',attach)
    if follow_path not in rest:follow_path=attach
    if rigid_item:used=set()
    order=sorted(used,key=lambda p:p.count('/'))
    names={path:f'{i:03d} '+re.sub(r'\[\d+\]$','',path.rsplit('/',1)[-1])[:45] for i,path in enumerate(order)}
    armature=bpy.data.armatures.new(item['name']+' - bones')
    arm=bpy.data.objects.new(item['name']+' - Offset',armature);collection.objects.link(arm)
    arm.parent=parent;arm['GMI']=True;arm['GMI_equipment']=True;arm['GMI_source']=item['path'];arm.show_in_front=True
    if context.object and context.object.mode!='OBJECT':bpy.ops.object.mode_set(mode='OBJECT')
    for obj in context.selected_objects:obj.select_set(False)
    arm.select_set(True);context.view_layer.objects.active=arm
    bpy.ops.object.mode_set(mode='EDIT')
    follow=armature.edit_bones.new('Suivi');follow.head=(0,0,0);follow.tail=(0,.1,0);follow.matrix=rest[follow_path]
    offset=armature.edit_bones.new('Offset');offset.head=(0,0,0);offset.tail=(0,.1,0);offset.matrix=rest[follow_path];offset.parent=follow
    for path in order:
        bone=armature.edit_bones.new(names[path]);bone.head=(0,0,0);bone.tail=(0,.05,0);bone.matrix=rest[path]
        ancestor=nodes[path].get('parent')
        while ancestor and ancestor not in used:ancestor=nodes.get(ancestor,{}).get('parent')
        bone.parent=armature.edit_bones[names[ancestor]] if ancestor in used else offset
    bpy.ops.object.mode_set(mode='OBJECT')
    for bone in arm.pose.bones:bone.rotation_mode='QUATERNION'
    arm.pose.bones['Offset'].rotation_mode='XYZ'
    controls=armature.collections.new('Offset');controls.assign(armature.bones['Offset'])
    deform=armature.collections.new('Deformation')
    for bone in armature.bones:
        if bone.name!='Offset':deform.assign(bone)
    deform.is_visible=False
    arm.animation_data_create();action=bpy.data.actions.new(item['name']+' - Mocap');arm.animation_data.action=action
    values={name:[] for name in ['Suivi',*names.values()]};previous={}
    for pose in samples:
        desired={'Suivi':pose[follow_path],'Offset':pose[follow_path],**{names[path]:pose[path] for path in order}}
        for name in values:
            bone=armature.bones[name];parent_bone=bone.parent
            options={'parent_matrix':desired[parent_bone.name],'parent_matrix_local':parent_bone.matrix_local} if parent_bone else {}
            basis=bone.convert_local_to_pose(desired[name],bone.matrix_local,invert=True,**options)
            loc,rot,scale=basis.decompose()
            if name in previous and previous[name].dot(rot)<0:rot=-rot
            previous[name]=rot.copy();values[name].append((*loc,*rot,*scale))
    for name,rows in values.items():
        columns=list(zip(*rows));prefix='pose.bones['+json.dumps(name)+']'
        for property,start,size in [('location',0,3),('rotation_quaternion',3,4),('scale',7,3)]:
            for axis in range(size):setdatasToCurves(frames,columns[start+axis],get_fcurve(action,arm,prefix+'.'+property,axis))
    obj=build_mesh(Path(item['_folder']),item,data,collection);obj.parent=arm
    from .shapes import build_shapes
    build_shapes(obj,item,data)
    if skinned and not rigid_item:
        groups={path:obj.vertex_groups.new(name=names[path]) for path in order}
        for vertex,influence in enumerate(weights):
            total=sum(max(0,w) for w in influence['weights'])
            if total<=0:raise ValueError('Sommet sans poids')
            for index,weight in zip(influence['bones'],influence['weights']):
                if weight>0:groups[skin_bones[index]].add([vertex],weight/total,'ADD')
    else:
        obj.vertex_groups.new(name='Offset').add(list(range(len(obj.data.vertices))),1,'REPLACE')
    modifier=obj.modifiers.new('Mocap skeleton','ARMATURE');modifier.object=arm
    arm['GMI_mesh']=obj.name
    return arm,obj

def body_appearance(raw,obj,frames):
    from . import list_existing_fcurves
    for line in raw:
        if not line.startswith('#appearance$'):continue
        fields=line.strip().split('$')
        try:frame=frames[int(fields[1])];color=tuple(float(v) for v in fields[3:7])
        except (ValueError,IndexError):continue
        if len(color)!=4 or not all(math.isfinite(v) for v in color):continue
        for slot in obj.material_slots:
            if slot.material and not slot.material.get('GMI_tintable',False):continue
            node=slot.material.node_tree.nodes.get('GMI_Tint') if slot.material else None
            if node:
                node.inputs[2].default_value=color;node.inputs[2].keyframe_insert('default_value',frame=frame)
    for slot in obj.material_slots:
        tree=slot.material.node_tree if slot.material else None
        action=tree.animation_data.action if tree and tree.animation_data else None
        if action:
            for curve in list_existing_fcurves(action,tree):
                for key in curve.keyframe_points:key.interpolation='CONSTANT'

def import_models(context,movement,rig):
    from . import scale_frame_range
    folder=Path(movement).resolve().parent;manifest=folder/'Models.json'
    if (folder/'CosmeticTimeline.json').is_file():
        from .live_models import import_timeline
        return import_timeline(context,movement,rig)
    if not manifest.is_file():return [],[]
    data=json.loads(manifest.read_text(encoding='utf-8-sig'))
    if data.get('schema')!=1:raise ValueError('Version Models.json inconnue')
    if 'skeleton' not in data or 'items' not in data:raise ValueError('Ancien export incomplet : refaire une prise avec UltimateMenu 1.7.96 ou plus recent')
    raw=Path(movement).read_text(encoding='utf-8-sig').splitlines();header=raw[0].lstrip('#').split('$')
    count=sum(bool(line.strip()) and not line.startswith('#') for line in raw)
    if not count:return [],[]
    rate=float(header[1]);frames=scale_frame_range(count,float(header[4].replace(',','.'))*rate,float(header[5].replace(',','.'))*rate)
    nodes={node['path']:node for node in data['skeleton']};rest={path:rigid(unity_matrix(node['matrix'])) for path,node in nodes.items()}
    parent=rig.parent
    if parent is None:raise ValueError('Offset joueur absent')
    samples=sample_motion(context,rig,parent,nodes,rest,frames)
    collection=bpy.data.collections.new('Modeles - '+data.get('player',rig.name));collection['GMI_owned']=True
    rig.users_collection[0].children.link(collection)
    imported=[];warnings=[]
    for item in data.get('items',[]):
        if item.get('kind')=='body':continue
        existing=set(collection.objects)
        try:
            if 'gorillaface' in item['name'].lower():
                from .live_models import apply_face
                values=[]
                for surface in item.get('materials',[]):
                    scale=surface.get('scale',{});offset=surface.get('offset',{});mouth_scale=surface.get('mouthScale',{});mouth_offset=surface.get('mouthOffset',{})
                    values.append((scale.get('x',1),scale.get('y',1),offset.get('x',0),offset.get('y',0),mouth_scale.get('x',1),mouth_scale.get('y',1),mouth_offset.get('x',0),mouth_offset.get('y',0)))
                apply_face(rig,folder,item,frames,[True]*len(frames),[values]*len(frames));continue
            geometry=json.loads(local_file(folder,item['geometry']).read_text(encoding='utf-8-sig'))
            item['_folder']=str(folder)
            arm,obj=equipment_rig(context,item,geometry,nodes,rest,parent,collection,frames,samples)
            imported.append(arm)
        except Exception as error:
            if context.object and context.object.mode!='OBJECT':bpy.ops.object.mode_set(mode='OBJECT')
            for obj in list(collection.objects):
                if obj not in existing:bpy.data.objects.remove(obj,do_unlink=True)
            warnings.append(item.get('name','Mesh')+': '+str(error))
    context.scene.frame_set(context.scene.frame_current)
    return imported,warnings
